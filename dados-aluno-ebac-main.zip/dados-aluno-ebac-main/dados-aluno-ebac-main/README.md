# Dados aluno
Faça a edição dos dados do arquivo dados.txt. 
Fique a vontade se não quiser responder todos os itens. 

### Instruções: 

-Faça um clone deste repositório em sua máquina;

-Edite o arquivo dados.txt;

-Crie um repositório no github com o nome aula-git-ebac;

-Faça o commit em seu repositório do github;

-No commit coloque a mensagem: “Modificando o arquivo de dados”.

-Compertilhe seu github conosco em nossa plataforma;